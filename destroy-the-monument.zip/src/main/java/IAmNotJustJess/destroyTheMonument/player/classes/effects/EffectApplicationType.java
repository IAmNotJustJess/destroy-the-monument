package IAmNotJustJess.destroyTheMonument.player.classes.effects;

public enum EffectApplicationType {
    APPLY_SELF,
    APPLY_ENEMIES_IN_RANGE,
    APPLY_ENEMIES_IN_RANGE_OF_CASTER,
    APPLY_TEAMMATES_IN_RANGE,
    APPLY_TEAMMATES_IN_RANGE_OF_CASTER
}
