package IAmNotJustJess.destroyTheMonument.player.classes.upgrades;

public enum UpgradeType {
    STACKING_FLAT_PER_KILL,
    STACKING_PERCENTAGE_PER_KILL,
    FLAT,
    PERCENTAGE
}
