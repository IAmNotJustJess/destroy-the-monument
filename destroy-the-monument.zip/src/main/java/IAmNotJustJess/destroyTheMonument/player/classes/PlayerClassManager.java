package IAmNotJustJess.destroyTheMonument.player.classes;

import java.util.ArrayList;

public class PlayerClassManager {
    private static final ArrayList<PlayerClass> list = new ArrayList<>();

    public static ArrayList<PlayerClass> getList() {
        return list;
    }
}
