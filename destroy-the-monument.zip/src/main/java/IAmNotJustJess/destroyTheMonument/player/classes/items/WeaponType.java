package IAmNotJustJess.destroyTheMonument.player.classes.items;

public enum WeaponType {
    MAIN_MELEE,
    MAIN_RANGED,
    MAIN_SPECIAL,
    SECONDARY_MELEE,
    SECONDARY_RANGED,
    SECONDARY_SPECIAL
}
