package IAmNotJustJess.destroyTheMonument.player.classes.skills;

public enum SkillType {
    PASSIVE,
    ACTIVATING_ON_HIT,
    ACTIVATING_ON_DEATH,
    ACTIVE
}
