package IAmNotJustJess.destroyTheMonument.player.classes.effects;

public enum EffectParticleSpawnLocation {
    USER,
    LOCATION,
    AFFECTED
}
