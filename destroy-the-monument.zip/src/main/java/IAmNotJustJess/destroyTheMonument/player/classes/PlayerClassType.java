package IAmNotJustJess.destroyTheMonument.player.classes;

public enum PlayerClassType {
    ATTACK,
    DEFENCE,
    SUPPORT
}
