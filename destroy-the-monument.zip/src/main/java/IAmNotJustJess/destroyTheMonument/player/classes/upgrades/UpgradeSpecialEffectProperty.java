package IAmNotJustJess.destroyTheMonument.player.classes.upgrades;

public enum UpgradeSpecialEffectProperty {
    NONE,
    ON_HIT,
    ON_ATTACK
}
