package IAmNotJustJess.destroyTheMonument.arenas;

public enum ArenaState {
    LOBBY,
    COUNTDOWN,
    STARTING,
    RUNNING,
    ENDING,
    CLEARING
}
